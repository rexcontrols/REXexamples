This document describes all jQuery modules with licences:

jQuery
=======================
- Source: https://jquery.org/
- Licence: [MIT][https://jquery.org/license/]

jQuery UI
=======================
- Source: http://jqueryui.com/
- Licence: [MIT][https://jquery.org/license/]

DISABLER
=======================
- http://dougestep.com/dme/jquery-disabler-widget
- Source: https://github.com/dgestep/jquery-disabler
- Licence: MIT, GPL

jQuery UI Touch Punch
=======================
- http://touchpunch.furf.com/
- Source: https://github.com/furf/jquery-ui-touch-punch
- Licence: MIT, GPL v2

jQuery Timepicker Addon
=======================
- Author: [Trent Richardson](http://trentrichardson.com)
- Documentation: [http://trentrichardson.com/examples/timepicker/](http://trentrichardson.com/examples/timepicker/)
- Source: https://github.com/trentrichardson/jQuery-Timepicker-Addon
- Licence: MIT